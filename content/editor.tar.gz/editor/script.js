var index = 0;
var numberQuestion;
function newOpros(){
  numberQuestion = 1;
  var newOpros =    "<div id=\"newOpros\" ><h1>Создание нового опроса</h1>	<button onClick=\"addQuestion()\" type=\"button\">Добавить вопрос</button>	<button onClick=\"sendToServer()\" type=\"button\">Сохранить опрос</button><p></p><form id=\"toServer\"><h2>Задать имя опроса</h2><p><input charset=\"UTF-8\" type=\"text\" name=\"nameSurvey\" required width=100%></p></form></div>"
  $('#content').html(newOpros);
};

function addQuestion(){

  $('#win').removeAttr("style");
  document.getElementById('inWindow').innerHTML = '<p>Наименование вопроса</p><p><input type="text" name="nameQuestion" required size="45"><input type="hidden" id="typeAnswer" name="typeAnswer" ></p><p>Выбрать тип ответа</p><p><input type="button" id="buttonCheck" value="checkbox" onclick="choiceTypeAnswer(\'checkbox\')" ><input type="button" id="buttonRadio" value="radio" onclick="choiceTypeAnswer(\'radio\')"><input type="button" id="buttonText" value="text" onclick="choiceTypeAnswer(\'text\')" ></p><p class="add"><input type="button" value="+" style="display:none;" ></p>';
  $('#inWindow').append('<div id="contentInWindow"></div>')
};

function newQuestion(){
  //var str = $('#changeAliasForm').serialize();
  var str = $("#changeAliasForm").serializeArray();
  var result = "";
  var typeAnswer = "null";
  var num = 0;

  if($("#changeAliasForm").valid()){

	 $.each(str,function(){

	   if (this.value == "checkbox"){
		  typeAnswer = "checkbox";
	   }else if (this.value == "text"){
		  typeAnswer = "text";
	   }else if (this.value == "radio"){
		  typeAnswer = "radio";
	   }
	 });

	 $.each(str,function(){
	   
       if (this.name == "nameQuestion"){
	     result += "<p><input class='styleFormQuestion' type='text' name='question" + numberQuestion + "' value='№ " + numberQuestion + " " + this.value + "' readonly ></p><p class='styleFormContext'>Возможные ответы :</p>";
	   }else if (!(this.name === "typeAnswer")){
		 num = num + 1;
	     result += "<p><input name='typeAnswer" + num + "' value='" + typeAnswer + "' type='" + typeAnswer + "'><input class='styleFormAnswer' name='answer" + num + "' type='text' value='" + this.value + "' readonly ></p>"
	   }
 	 });

	 numberQuestion = numberQuestion + 1;
     $('#toServer').append(result);
     $('#win').css('display','none');
  }

//$(document).ready(function(){
  /* $("form").validate({
       rules:{
            nameQuestion:{
                required: true,
            },
            typeAnswer:{
                required: true,
            },
       },
       messages:{
            nameQuestion:{
                required: "Это поле обязательно для заполнения",
            },
            typeAnswer:{
                required: "Это поле обязательно для заполнения",
            },
       }
//    });

  });*/  
};

function del(button){
  index = index + 1;
  var type = document.getElementById("contentInWindow");
  var row = button.parentNode;
  type.removeChild(row);
  if ($('input[value="+"]').length < 2){
    $('#buttonText').prop('disabled',false);
    $('#buttonCheck').prop('disabled',false);
    $('#buttonRadio').prop('disabled',false);
  };
};

function choiceTypeAnswer(flag){
  var countAnswer = $('input[value="+"]').length;
  if (countAnswer == 1){
    index = 1;
    $('#buttonText').prop('disabled',true);
    $('#buttonCheck').prop('disabled',true);
    $('#buttonRadio').prop('disabled',true);
  }else{
    index = index + 1;
  }
  
  if (flag == "checkbox"){
	$('#contentInWindow').append('<p id="rowCheckbox"><input type="button" value="+" onclick=choiceTypeAnswer(\'checkbox\')><input type="checkbox"><input type="text" name="answer' + index + '" required placeholder="Наименование ответа"><input type="button" onclick="del(this)" value="del"></p>');	
	$('#typeAnswer').val("checkbox");
  }
  else if (flag == "text"){$('#contentInWindow').append('<p id="rowText"><input type="button" value="+" onclick=choiceTypeAnswer(\'text\')><input type="text" name="answer' + index + '" placeholder="Наименование ответа"><input type="button" onclick="del(this)" value="del"></p>');
	$('#typeAnswer').val("text");
  }
  else if (flag == "radio"){$('#contentInWindow').append('<p id="rowRadio"><input type="button" value="+" onclick=choiceTypeAnswer(\'radio\')><input type="radio" ><input type="text" name="answer' + index + '" required placeholder="Наименование ответа"><input type="button" onclick="del(this)" value="del"></p>');
	$('#typeAnswer').val("radio");
  };

};

function sendToServer(){
  var str = $('#toServer').serialize();
  alert(str);
};





